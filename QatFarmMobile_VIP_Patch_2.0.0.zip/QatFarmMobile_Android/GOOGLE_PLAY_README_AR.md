# نسخة Google Play — نظام مزارع القات VIP 2.0.0

هذه النسخة مجهزة تقنيًا لبناء Android App Bundle (AAB) للنشر على Google Play.

## الإعدادات
- Application ID: `com.qatfarm.mobile`
- Version name: `2.0.0`
- Version code: `20`
- Target framework/API: `.NET 10 / Android API 36`
- Minimum Android: API 24 (Android 7.0)
- Package formats: AAB للمتجر + APK للتثبيت المباشر
- Architectures: ARM32, ARM64, x86, x64
- لا توجد صلاحيات Android حساسة مصرح بها في AndroidManifest.xml.
- تم تعطيل Android Auto Backup لأن التطبيق لديه نسخ احتياطي يدوي خاص به.

## قبل النشر
1. أنشئ مفتاح رفع جديداً وخزّنه في GitHub Secrets، ثم فعّل خطوة بناء AAB الموقعة.
2. أول AAB يجب رفعه يدويًا من Play Console.
3. لكل إصدار جديد يجب زيادة `ApplicationVersion` (versionCode).
4. فعّل Google Play App Signing واحتفظ بمفتاح الرفع الحالي بأمان.
5. ارفع سياسة الخصوصية الموجودة في `StoreAssets/privacy-policy-ar.html` إلى رابط HTTPS عام وثابت، ثم ضع الرابط في Play Console.
6. أكمل نموذج Data safety والتصنيف العمري ومعلومات الوصول للتطبيق للمراجعة.
7. تأكد من أن البلدان التي توزع فيها التطبيق تسمح بالنشاط الذي يديره التطبيق، وأن وصف المتجر دقيق ولا يخفي طبيعة التطبيق.

## ملاحظة مهمة عن مفتاح التوقيع
لا تضع ملف التوقيع أو كلمة مروره داخل المستودع أو أرشيف المصدر. استخدم GitHub Secrets ومفتاح رفع جديداً فقط.
