using QatFarm.Mobile.Data;
using QatFarm.Mobile.Models;

namespace QatFarm.Mobile.Services;

public sealed class AppSession
{
    private readonly MobileDb _db;
    public AppSession(MobileDb db) => _db = db;

    public AppUser? CurrentUser { get; private set; }
    public bool IsAuthenticated => CurrentUser is not null;
    public bool IsAdmin => CurrentUser?.Role == UserRole.Administrator;
    public bool CanRecordPayments => CurrentUser?.Role is UserRole.Administrator or UserRole.Accountant;
    public event Action? Changed;

    public async Task<bool> HasUsersAsync()
    {
        var db = await _db.GetAsync();
        return await db.Table<AppUser>().Where(x => !x.IsDeleted).CountAsync() > 0;
    }

    public async Task<(bool Success, string Message)> CreateFirstAdministratorAsync(FirstRunAdminModel model)
    {
        var db = await _db.GetAsync();
        if (await db.Table<AppUser>().Where(x => !x.IsDeleted).CountAsync() > 0)
            return (false, "تم إنشاء حساب الإدارة مسبقاً.");
        if (string.IsNullOrWhiteSpace(model.FullName)) return (false, "اسم المدير مطلوب.");
        if (string.IsNullOrWhiteSpace(model.Email) || !model.Email.Contains('@')) return (false, "أدخل بريداً إلكترونياً صحيحاً.");
        if (string.IsNullOrWhiteSpace(model.Password) || model.Password.Length < 10)
            return (false, "كلمة المرور يجب ألا تقل عن 10 أحرف.");
        if (model.Password != model.ConfirmPassword) return (false, "تأكيد كلمة المرور غير مطابق.");

        var (hash, salt) = PasswordHasher.HashPassword(model.Password);
        var user = new AppUser
        {
            FullName = model.FullName.Trim(),
            Email = model.Email.Trim().ToLowerInvariant(),
            PasswordHash = hash,
            PasswordSalt = salt,
            Role = UserRole.Administrator,
            IsActive = true,
            LastLoginAt = DateTime.Now
        };
        await db.InsertAsync(user);
        CurrentUser = user;
        Changed?.Invoke();
        return (true, string.Empty);
    }

    public async Task<(bool Success, string Message)> LoginAsync(string email, string password)
    {
        var db = await _db.GetAsync();
        var normalized = email.Trim().ToLowerInvariant();
        var user = await db.Table<AppUser>()
            .Where(x => x.Email == normalized && !x.IsDeleted)
            .FirstOrDefaultAsync();
        if (user is null || !user.IsActive) return (false, "الحساب غير موجود أو موقوف.");
        if (!PasswordHasher.Verify(password, user.PasswordHash, user.PasswordSalt))
            return (false, "كلمة المرور غير صحيحة.");
        user.LastLoginAt = DateTime.Now;
        await db.UpdateAsync(user);
        CurrentUser = user;
        Changed?.Invoke();
        return (true, string.Empty);
    }

    public void Logout() { CurrentUser = null; Changed?.Invoke(); }
}
