# نسخة Google Play — نظام مزارع القات 1.2.0

هذه النسخة مجهزة تقنيًا لبناء Android App Bundle (AAB) للنشر على Google Play.

## الإعدادات
- Application ID: `com.qatfarm.mobile`
- Version name: `1.2.0`
- Version code: `9`
- Target framework/API: `.NET 10 / Android API 36`
- Minimum Android: API 24 (Android 7.0)
- Package formats: AAB للمتجر + APK للتثبيت المباشر
- Architectures: ARM32, ARM64, x86, x64
- لا توجد صلاحيات Android حساسة مصرح بها في AndroidManifest.xml.
- تم تعطيل Android Auto Backup لأن التطبيق لديه نسخ احتياطي يدوي خاص به.

## قبل النشر
1. شغّل Workflow الخاص بـ Google Play لبناء ملف `QatFarmMobile-GooglePlay-1.2.0.aab`.
2. أول AAB يجب رفعه يدويًا من Play Console.
3. لكل إصدار جديد يجب زيادة `ApplicationVersion` (versionCode).
4. فعّل Google Play App Signing واحتفظ بمفتاح الرفع الحالي بأمان.
5. ارفع سياسة الخصوصية الموجودة في `StoreAssets/privacy-policy-ar.html` إلى رابط HTTPS عام وثابت، ثم ضع الرابط في Play Console.
6. أكمل نموذج Data safety والتصنيف العمري ومعلومات الوصول للتطبيق للمراجعة.
7. تأكد من أن البلدان التي توزع فيها التطبيق تسمح بالنشاط الذي يديره التطبيق، وأن وصف المتجر دقيق ولا يخفي طبيعة التطبيق.

## ملاحظة مهمة عن مفتاح التوقيع
ملف التوقيع الموجود في مجلد Signing هو مفتاح إصدار حقيقي ويجب عدم نشره في مستودع عام أو مشاركته مع أي شخص.
