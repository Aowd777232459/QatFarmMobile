@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
dotnet workload install maui-android
if errorlevel 1 goto :failed
dotnet build "QatFarm.Mobile\QatFarm.Mobile.csproj" -f net10.0-android -c Debug
if errorlevel 1 goto :failed
if not exist "Release" mkdir "Release"
for /r "QatFarm.Mobile\bin\Debug\net10.0-android" %%F in (*.apk) do copy /y "%%F" "Release\QatFarmMobile-Debug.apk" >nul
echo APK created in Release\QatFarmMobile-Debug.apk
pause
exit /b 0
:failed
echo Build failed.
pause
exit /b 1
