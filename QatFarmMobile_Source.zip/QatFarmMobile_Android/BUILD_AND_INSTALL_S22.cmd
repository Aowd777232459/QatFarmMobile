@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

set "QATFARM_NO_PAUSE=1"
call "%~dp0BUILD_ANDROID_APK.cmd"
if errorlevel 1 (
  echo ERROR: APK build failed.
  pause
  exit /b 1
)

set "ADB="
for /f "delims=" %%I in ('where adb.exe 2^>nul') do if not defined ADB set "ADB=%%I"
if not defined ADB if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not defined ADB if exist "%ProgramFiles(x86)%\Android\android-sdk\platform-tools\adb.exe" set "ADB=%ProgramFiles(x86)%\Android\android-sdk\platform-tools\adb.exe"

if not defined ADB (
  echo APK is ready, but adb.exe was not found.
  echo Copy Release\QatFarmMobile.apk to the phone and install it manually.
  pause
  exit /b 0
)

echo.
echo Connect the Samsung S22 Ultra with USB debugging enabled.
"%ADB%" start-server
"%ADB%" devices
echo.
echo Installing APK...
"%ADB%" install -r "%~dp0Release\QatFarmMobile.apk"
if errorlevel 1 (
  echo Installation failed. Accept the USB debugging prompt on the phone and run this file again.
  pause
  exit /b 1
)

echo SUCCESS: QatFarm Mobile was installed on the phone.
pause
exit /b 0
