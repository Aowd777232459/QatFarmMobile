@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo QatFarm Mobile - Prepare Android build tools
echo ============================================================

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET 10 SDK is not installed.
  pause
  exit /b 1
)

echo Installing .NET MAUI Android workload...
dotnet workload install maui-android
if not errorlevel 1 goto :success

echo The command-line workload was not enough. Checking Visual Studio...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSINSTALLER=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\setup.exe"
if not exist "%VSWHERE%" (
  echo ERROR: Visual Studio Installer was not found.
  echo Open Visual Studio Installer manually and add:
  echo Mobile development with .NET
  pause
  exit /b 1
)

for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -property installationPath`) do set "VSPATH=%%I"
if not defined VSPATH (
  echo ERROR: No Visual Studio installation was found.
  pause
  exit /b 1
)

if not exist "%VSINSTALLER%" (
  echo ERROR: Visual Studio setup.exe was not found.
  pause
  exit /b 1
)

echo Installing the Visual Studio Mobile development with .NET workload...
"%VSINSTALLER%" modify --installPath "%VSPATH%" --add Microsoft.VisualStudio.Workload.NetCrossPlat --includeRecommended --passive --norestart
if errorlevel 1 (
  echo ERROR: Visual Studio mobile workload installation failed.
  pause
  exit /b 1
)

dotnet workload install maui-android
if errorlevel 1 (
  echo ERROR: MAUI Android workload is still unavailable.
  pause
  exit /b 1
)

:success
echo Android build tools are ready.
pause
exit /b 0
