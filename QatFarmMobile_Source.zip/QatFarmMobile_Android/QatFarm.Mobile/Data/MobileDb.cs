using Microsoft.Maui.Storage;
using QatFarm.Mobile.Models;
using QatFarm.Mobile.Services;
using SQLite;

namespace QatFarm.Mobile.Data;

public sealed class MobileDb
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private SQLiteAsyncConnection? _db;
    private bool _initialized;

    public string DatabasePath => Path.Combine(FileSystem.AppDataDirectory, "QatFarmMobile.db3");

    public async Task<SQLiteAsyncConnection> GetAsync()
    {
        _db ??= new SQLiteAsyncConnection(DatabasePath,
            SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);
        if (!_initialized) await InitializeAsync();
        return _db;
    }

    public async Task InitializeAsync()
    {
        await _gate.WaitAsync();
        try
        {
            if (_initialized) return;
            _db ??= new SQLiteAsyncConnection(DatabasePath,
                SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);
            await _db.EnableWriteAheadLoggingAsync();
            await _db.CreateTablesAsync(CreateFlags.None,
                typeof(AppUser), typeof(Farm), typeof(Customer), typeof(Creditor),
                typeof(CultivationExpenseType), typeof(CultivationExpense),
                typeof(CultivationDebtPayment), typeof(QatType), typeof(DailyExpenseType),
                typeof(SalesInvoice), typeof(SalesInvoiceItem), typeof(InvoiceExpense),
                typeof(CustomerPayment), typeof(AuditLog), typeof(SystemSetting));
            await SeedAsync(_db);
            _initialized = true;
        }
        finally { _gate.Release(); }
    }

    private static async Task SeedAsync(SQLiteAsyncConnection db)
    {
        if (await db.Table<AppUser>().CountAsync() == 0)
        {
            var (hash, salt) = PasswordHasher.HashPassword("Qat@2026#ChangeMe");
            await db.InsertAsync(new AppUser
            {
                FullName = "عبد الملك عواد",
                Email = "abdulmalik.awad@qat.local",
                PasswordHash = hash, PasswordSalt = salt,
                Role = UserRole.Administrator, IsActive = true
            });
        }

        if (await db.Table<CultivationExpenseType>().CountAsync() == 0)
        {
            foreach (var name in new[] {"السقي","أجور العمال","السم الحديدي","السماد","المبيدات","النقل","الصيانة","أخرى"})
                await db.InsertAsync(new CultivationExpenseType { Name = name });
        }

        if (await db.Table<QatType>().CountAsync() == 0)
        {
            foreach (var name in new[] {"أميال رقم واحد","أميال مخضر","بزغة مخضر","قات عادي","نوع آخر"})
                await db.InsertAsync(new QatType { Name = name });
        }

        if (await db.Table<DailyExpenseType>().CountAsync() == 0)
        {
            foreach (var name in new[] {"عمال","نقل","سقي","تغليف","عمولة","أخرى"})
                await db.InsertAsync(new DailyExpenseType { Name = name });
        }
    }

    public async Task CheckpointAsync()
    {
        var db = await GetAsync();
        await db.ExecuteAsync("PRAGMA wal_checkpoint(FULL);");
    }

    public async Task ReplaceDatabaseAsync(Stream source)
    {
        await _gate.WaitAsync();
        try
        {
            if (_db is not null) { await _db.CloseAsync(); _db = null; }
            var temp = DatabasePath + ".import";
            await using (var output = File.Create(temp)) await source.CopyToAsync(output);
            if (File.Exists(DatabasePath)) File.Copy(DatabasePath, DatabasePath + ".before-import", true);
            File.Copy(temp, DatabasePath, true);
            File.Delete(temp);
            _initialized = false;
        }
        finally { _gate.Release(); }
        await InitializeAsync();
    }
}
