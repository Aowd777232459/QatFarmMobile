using System.Text.Json;
using QatFarm.Mobile.Data;
using QatFarm.Mobile.Models;
using SQLite;

namespace QatFarm.Mobile.Services;

public sealed class QatFarmService
{
    private readonly MobileDb _db;
    private readonly AppSession _session;

    public QatFarmService(MobileDb db, AppSession session)
    {
        _db = db;
        _session = session;
    }

    private async Task<SQLiteAsyncConnection> DbAsync() => await _db.GetAsync();

    private void EnsureAdmin()
    {
        if (!_session.IsAdmin) throw new InvalidOperationException("هذه العملية متاحة للمدير فقط.");
    }

    private async Task AuditAsync(string action, string entity, long id, object? oldValue = null, object? newValue = null)
    {
        var db = await DbAsync();
        await db.InsertAsync(new AuditLog
        {
            UserId = _session.CurrentUser?.Id,
            UserName = _session.CurrentUser?.FullName ?? "النظام",
            Action = action,
            EntityName = entity,
            EntityId = id.ToString(),
            OldValues = oldValue is null ? null : JsonSerializer.Serialize(oldValue),
            NewValues = newValue is null ? null : JsonSerializer.Serialize(newValue),
            ActionDate = DateTime.Now
        });
    }

    public async Task<List<Farm>> GetFarmsAsync(bool activeOnly = false)
    {
        var db = await DbAsync();
        var rows = await db.Table<Farm>().Where(x => !x.IsDeleted).OrderBy(x => x.Name).ToListAsync();
        return activeOnly ? rows.Where(x => x.IsActive).ToList() : rows;
    }

    public async Task SaveFarmAsync(Farm model)
    {
        if (string.IsNullOrWhiteSpace(model.Name)) throw new InvalidOperationException("اسم المزرعة مطلوب.");
        var db = await DbAsync();
        if (model.Id == 0)
        {
            model.Name = model.Name.Trim();
            await db.InsertAsync(model);
            await AuditAsync("إضافة", nameof(Farm), model.Id, null, model);
        }
        else
        {
            EnsureAdmin();
            var old = await db.FindAsync<Farm>(model.Id) ?? throw new InvalidOperationException("المزرعة غير موجودة.");
            model.CreatedAt = old.CreatedAt;
            model.UpdatedAt = DateTime.Now;
            await db.UpdateAsync(model);
            await AuditAsync("تعديل", nameof(Farm), model.Id, old, model);
        }
    }

    public async Task DeleteFarmAsync(long id)
    {
        EnsureAdmin();
        var db = await DbAsync();
        var item = await db.FindAsync<Farm>(id);
        if (item is null) return;
        item.IsDeleted = true;
        item.IsActive = false;
        item.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(item);
        await AuditAsync("حذف منطقي", nameof(Farm), id, item, null);
    }

    public async Task<List<CustomerBalanceRow>> GetCustomersAsync()
    {
        var db = await DbAsync();
        var customers = await db.Table<Customer>().Where(x => !x.IsDeleted).OrderBy(x => x.Name).ToListAsync();
        var invoices = await db.Table<SalesInvoice>().Where(x => !x.IsDeleted && x.Status == InvoiceStatus.Posted).ToListAsync();
        var payments = await db.Table<CustomerPayment>().Where(x => !x.IsDeleted).ToListAsync();
        return customers.Select(c => new CustomerBalanceRow
        {
            Customer = c,
            Invoiced = invoices.Where(i => i.CustomerId == c.Id).Sum(i => i.GrossAmount),
            Paid = invoices.Where(i => i.CustomerId == c.Id).Sum(i => i.AmountPaid)
                   + payments.Where(p => p.CustomerId == c.Id && p.SalesInvoiceId == null).Sum(p => p.Amount)
        }).ToList();
    }

    public async Task<List<Customer>> GetCustomerLookupsAsync()
    {
        var db = await DbAsync();
        return await db.Table<Customer>().Where(x => !x.IsDeleted && x.IsActive).OrderBy(x => x.Name).ToListAsync();
    }

    public async Task SaveCustomerAsync(Customer model)
    {
        if (string.IsNullOrWhiteSpace(model.Name)) throw new InvalidOperationException("اسم العميل مطلوب.");
        var db = await DbAsync();
        if (model.Id == 0)
        {
            model.Name = model.Name.Trim();
            await db.InsertAsync(model);
            await AuditAsync("إضافة", nameof(Customer), model.Id, null, model);
        }
        else
        {
            EnsureAdmin();
            var old = await db.FindAsync<Customer>(model.Id) ?? throw new InvalidOperationException("العميل غير موجود.");
            model.CreatedAt = old.CreatedAt;
            model.UpdatedAt = DateTime.Now;
            await db.UpdateAsync(model);
            await AuditAsync("تعديل", nameof(Customer), model.Id, old, model);
        }
    }

    public async Task DeleteCustomerAsync(long id)
    {
        EnsureAdmin();
        var db = await DbAsync();
        var item = await db.FindAsync<Customer>(id);
        if (item is null) return;
        item.IsDeleted = true;
        item.IsActive = false;
        item.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(item);
        await AuditAsync("حذف منطقي", nameof(Customer), id, item, null);
    }

    public async Task AddCustomerPaymentAsync(long customerId, long? invoiceId, decimal amount, PaymentMethod method, string? reference)
    {
        if (!_session.CanRecordPayments) throw new InvalidOperationException("تسجيل الدفعات متاح للمدير أو المحاسب.");
        if (amount <= 0) throw new InvalidOperationException("مبلغ الدفعة يجب أن يكون أكبر من صفر.");
        var db = await DbAsync();
        var payment = new CustomerPayment
        {
            CustomerId = customerId,
            SalesInvoiceId = invoiceId,
            Amount = amount,
            PaymentMethod = method,
            ReferenceNumber = reference,
            PaymentDate = DateTime.Now
        };
        await db.InsertAsync(payment);
        if (invoiceId.HasValue)
        {
            var invoice = await db.FindAsync<SalesInvoice>(invoiceId.Value)
                ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
            invoice.AmountPaid = Math.Min(invoice.GrossAmount, invoice.AmountPaid + amount);
            invoice.AmountDue = Math.Max(0, invoice.GrossAmount - invoice.AmountPaid);
            invoice.PaymentStatus = invoice.AmountDue == 0 ? PaymentStatus.Paid :
                invoice.AmountPaid > 0 ? PaymentStatus.Partial : PaymentStatus.Unpaid;
            invoice.UpdatedAt = DateTime.Now;
            await db.UpdateAsync(invoice);
        }
        await AuditAsync("تسجيل دفعة عميل", nameof(CustomerPayment), payment.Id, null, payment);
    }

    public async Task<List<Creditor>> GetCreditorsAsync(bool activeOnly = false)
    {
        var db = await DbAsync();
        var rows = await db.Table<Creditor>().Where(x => !x.IsDeleted).OrderBy(x => x.Name).ToListAsync();
        return activeOnly ? rows.Where(x => x.IsActive).ToList() : rows;
    }

    public async Task SaveCreditorAsync(Creditor model)
    {
        if (string.IsNullOrWhiteSpace(model.Name)) throw new InvalidOperationException("اسم الدائن مطلوب.");
        var db = await DbAsync();
        if (model.Id == 0)
        {
            model.Name = model.Name.Trim();
            await db.InsertAsync(model);
            await AuditAsync("إضافة", nameof(Creditor), model.Id, null, model);
        }
        else
        {
            EnsureAdmin();
            var old = await db.FindAsync<Creditor>(model.Id) ?? throw new InvalidOperationException("الدائن غير موجود.");
            model.CreatedAt = old.CreatedAt;
            model.UpdatedAt = DateTime.Now;
            await db.UpdateAsync(model);
            await AuditAsync("تعديل", nameof(Creditor), model.Id, old, model);
        }
    }

    public async Task DeleteCreditorAsync(long id)
    {
        EnsureAdmin();
        var db = await DbAsync();
        var item = await db.FindAsync<Creditor>(id);
        if (item is null) return;
        item.IsDeleted = true;
        item.IsActive = false;
        item.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(item);
        await AuditAsync("حذف منطقي", nameof(Creditor), id, item, null);
    }

    public async Task<List<CultivationExpenseType>> GetCultivationTypesAsync()
    {
        var db = await DbAsync();
        return await db.Table<CultivationExpenseType>().Where(x => !x.IsDeleted && x.IsActive).OrderBy(x => x.Name).ToListAsync();
    }

    public async Task<List<CultivationExpenseRow>> GetCultivationExpensesAsync(long? farmId, int year)
    {
        var db = await DbAsync();
        var from = new DateTime(year, 1, 1);
        var to = from.AddYears(1);
        var expenses = await db.Table<CultivationExpense>()
            .Where(x => !x.IsDeleted && x.ExpenseDate >= from && x.ExpenseDate < to)
            .OrderByDescending(x => x.ExpenseDate).ToListAsync();

        if (farmId.HasValue && farmId.Value > 0)
            expenses = expenses.Where(x => x.FarmId == farmId.Value).ToList();

        var farms = (await GetFarmsAsync()).ToDictionary(x => x.Id, x => x.Name);
        var types = (await GetCultivationTypesAsync()).ToDictionary(x => x.Id, x => x.Name);
        var creditors = (await GetCreditorsAsync()).ToDictionary(x => x.Id, x => x.Name);

        return expenses.Select(x => new CultivationExpenseRow
        {
            Expense = x,
            FarmName = farms.GetValueOrDefault(x.FarmId, "غير معروف"),
            ExpenseTypeName = types.GetValueOrDefault(x.ExpenseTypeId, "غير معروف"),
            CreditorName = x.CreditorId.HasValue ? creditors.GetValueOrDefault(x.CreditorId.Value, "غير معروف") : string.Empty
        }).ToList();
    }

    public async Task SaveCultivationExpenseAsync(CultivationExpense model)
    {
        if (model.FarmId <= 0 || model.ExpenseTypeId <= 0 || model.Amount <= 0)
            throw new InvalidOperationException("اختر المزرعة والنوع وأدخل مبلغًا صحيحًا.");

        if (model.PaymentType == CultivationExpensePaymentType.Cash)
        {
            model.PaidAmount = model.Amount;
            model.CreditorId = null;
            model.DueDate = null;
            model.DebtStatus = CultivationDebtStatus.NoDebt;
        }
        else
        {
            if (!model.CreditorId.HasValue || model.CreditorId <= 0)
                throw new InvalidOperationException("اختر الدائن عند تسجيل خسارة آجلة.");
            if (model.PaidAmount < 0 || model.PaidAmount > model.Amount)
                throw new InvalidOperationException("المبلغ المدفوع غير صحيح.");
            model.DebtStatus = model.PaidAmount <= 0 ? CultivationDebtStatus.Unpaid :
                model.PaidAmount >= model.Amount ? CultivationDebtStatus.Paid : CultivationDebtStatus.Partial;
        }

        if (string.IsNullOrWhiteSpace(model.ReceiptNumber))
            model.ReceiptNumber = $"CE-{DateTime.Now:yyyyMMddHHmmss}";

        var db = await DbAsync();
        if (model.Id == 0)
        {
            await db.InsertAsync(model);
            await AuditAsync("إضافة خسارة تربية", nameof(CultivationExpense), model.Id, null, model);
        }
        else
        {
            EnsureAdmin();
            var old = await db.FindAsync<CultivationExpense>(model.Id)
                ?? throw new InvalidOperationException("الخسارة غير موجودة.");
            model.CreatedAt = old.CreatedAt;
            model.UpdatedAt = DateTime.Now;
            await db.UpdateAsync(model);
            await AuditAsync("تعديل خسارة تربية", nameof(CultivationExpense), model.Id, old, model);
        }
    }

    public async Task DeleteCultivationExpenseAsync(long id)
    {
        EnsureAdmin();
        var db = await DbAsync();
        var item = await db.FindAsync<CultivationExpense>(id);
        if (item is null) return;
        item.IsDeleted = true;
        item.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(item);
        await AuditAsync("حذف خسارة تربية", nameof(CultivationExpense), id, item, null);
    }

    public async Task AddCultivationDebtPaymentAsync(long expenseId, decimal amount, PaymentMethod method, string? reference)
    {
        if (!_session.CanRecordPayments) throw new InvalidOperationException("تسجيل الدفعات متاح للمدير أو المحاسب.");
        if (amount <= 0) throw new InvalidOperationException("أدخل مبلغًا صحيحًا.");

        var db = await DbAsync();
        var expense = await db.FindAsync<CultivationExpense>(expenseId)
            ?? throw new InvalidOperationException("الخسارة غير موجودة.");
        var outstanding = Math.Max(0, expense.Amount - expense.PaidAmount);
        if (amount > outstanding) throw new InvalidOperationException($"الدفعة أكبر من المتبقي ({outstanding:N2}).");

        var payment = new CultivationDebtPayment
        {
            CultivationExpenseId = expense.Id,
            CreditorId = expense.CreditorId ?? 0,
            Amount = amount,
            PaymentMethod = method,
            ReferenceNumber = reference,
            PaymentDate = DateTime.Now
        };
        await db.InsertAsync(payment);
        expense.PaidAmount += amount;
        expense.DebtStatus = expense.PaidAmount >= expense.Amount ? CultivationDebtStatus.Paid : CultivationDebtStatus.Partial;
        expense.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(expense);
        await AuditAsync("سداد دين تربية", nameof(CultivationDebtPayment), payment.Id, null, payment);
    }


    public async Task<List<CultivationDebtPayment>> GetCultivationDebtPaymentsAsync(IEnumerable<long> expenseIds)
    {
        var ids = expenseIds.Distinct().ToHashSet();
        if (ids.Count == 0) return [];
        var db = await DbAsync();
        var rows = await db.Table<CultivationDebtPayment>()
            .Where(x => !x.IsDeleted)
            .OrderBy(x => x.PaymentDate).ToListAsync();
        return rows.Where(x => ids.Contains(x.CultivationExpenseId)).ToList();
    }


    public async Task<List<QatType>> GetQatTypesAsync()
    {
        var db = await DbAsync();
        return await db.Table<QatType>().Where(x => !x.IsDeleted && x.IsActive).OrderBy(x => x.Name).ToListAsync();
    }

    public async Task<List<DailyExpenseType>> GetDailyExpenseTypesAsync()
    {
        var db = await DbAsync();
        return await db.Table<DailyExpenseType>().Where(x => !x.IsDeleted && x.IsActive).OrderBy(x => x.Name).ToListAsync();
    }

    public async Task<InvoiceEditorModel> GetInvoiceEditorAsync(long id)
    {
        var db = await DbAsync();
        var invoice = await db.FindAsync<SalesInvoice>(id)
            ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
        var items = await db.Table<SalesInvoiceItem>().Where(x => x.InvoiceId == id && !x.IsDeleted).ToListAsync();
        var expenses = await db.Table<InvoiceExpense>().Where(x => x.InvoiceId == id && !x.IsDeleted).ToListAsync();

        return new InvoiceEditorModel
        {
            Id = invoice.Id, FarmId = invoice.FarmId, CustomerId = invoice.CustomerId,
            InvoiceDate = invoice.InvoiceDate, PaymentDueDate = invoice.PaymentDueDate,
            BuyerName = invoice.BuyerName, BuyerPhone = invoice.BuyerPhone,
            ZakatPercent = invoice.ZakatPercent, AmountPaid = invoice.AmountPaid,
            PaymentMethod = invoice.PaymentMethod, Notes = invoice.Notes,
            Items = items.Select(x => new InvoiceItemInput
            {
                QatTypeId = x.QatTypeId, Quantity = x.Quantity, UnitPrice = x.UnitPrice
            }).ToList(),
            Expenses = expenses.Select(x => new InvoiceExpenseInput
            {
                ExpenseTypeId = x.ExpenseTypeId, Amount = x.Amount, Notes = x.Notes
            }).ToList()
        };
    }

    public async Task<long> SaveInvoiceAsync(InvoiceEditorModel model)
    {
        if (model.FarmId <= 0) throw new InvalidOperationException("اختر المزرعة.");
        if (model.Items.Count == 0 || model.Items.Any(x => x.QatTypeId <= 0 || x.Quantity <= 0 || x.UnitPrice <= 0))
            throw new InvalidOperationException("أدخل صنفًا واحدًا صحيحًا على الأقل.");
        if (model.AmountPaid < 0 || model.AmountPaid > model.GrossAmount)
            throw new InvalidOperationException("المبلغ المدفوع غير صحيح.");

        var db = await DbAsync();
        SalesInvoice invoice;
        if (model.Id == 0)
            invoice = new SalesInvoice { InvoiceNumber = $"INV-{DateTime.Now:yyyyMMdd-HHmmssfff}" };
        else
        {
            EnsureAdmin();
            invoice = await db.FindAsync<SalesInvoice>(model.Id)
                ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
        }

        var old = model.Id == 0 ? null : JsonSerializer.Serialize(invoice);
        var previousZakatAmount = invoice.ZakatAmount;
        invoice.FarmId = model.FarmId;
        invoice.CustomerId = model.CustomerId;
        invoice.InvoiceDate = model.InvoiceDate;
        invoice.PaymentDueDate = model.PaymentDueDate;
        invoice.BuyerName = model.BuyerName;
        invoice.BuyerPhone = model.BuyerPhone;
        invoice.GrossAmount = model.GrossAmount;
        invoice.ZakatPercent = model.ZakatPercent;
        invoice.ZakatAmount = model.ZakatAmount;
        invoice.TotalExpenses = model.TotalExpenses;
        invoice.NetAmount = model.NetAmount;
        invoice.AmountPaid = model.AmountPaid;
        invoice.AmountDue = model.AmountDue;
        invoice.PaymentMethod = model.PaymentMethod;
        invoice.PaymentStatus = invoice.AmountDue == 0 ? PaymentStatus.Paid :
            invoice.AmountPaid > 0 ? PaymentStatus.Partial : PaymentStatus.Unpaid;
        invoice.Notes = model.Notes;
        invoice.Status = InvoiceStatus.Posted;
        if (model.Id == 0 || (invoice.ZakatStatus == ZakatPaymentStatus.Paid && previousZakatAmount != model.ZakatAmount))
        {
            invoice.ZakatStatus = model.ZakatAmount > 0 ? ZakatPaymentStatus.Pending : ZakatPaymentStatus.NotApplicable;
            invoice.ZakatPaidAt = null;
            invoice.ZakatPaymentReference = null;
        }
        invoice.UpdatedAt = model.Id == 0 ? null : DateTime.Now;

        if (model.Id == 0) await db.InsertAsync(invoice); else await db.UpdateAsync(invoice);

        var oldItems = await db.Table<SalesInvoiceItem>().Where(x => x.InvoiceId == invoice.Id).ToListAsync();
        var oldExpenses = await db.Table<InvoiceExpense>().Where(x => x.InvoiceId == invoice.Id).ToListAsync();
        foreach (var x in oldItems) await db.DeleteAsync(x);
        foreach (var x in oldExpenses) await db.DeleteAsync(x);

        foreach (var item in model.Items)
            await db.InsertAsync(new SalesInvoiceItem
            {
                InvoiceId = invoice.Id, QatTypeId = item.QatTypeId,
                Quantity = item.Quantity, UnitPrice = item.UnitPrice, TotalPrice = item.Total
            });

        foreach (var expense in model.Expenses.Where(x => x.ExpenseTypeId > 0 && x.Amount > 0))
            await db.InsertAsync(new InvoiceExpense
            {
                InvoiceId = invoice.Id, ExpenseTypeId = expense.ExpenseTypeId,
                Amount = expense.Amount, Notes = expense.Notes
            });

        await AuditAsync(model.Id == 0 ? "إنشاء فاتورة" : "تعديل فاتورة",
            nameof(SalesInvoice), invoice.Id, old, invoice);
        return invoice.Id;
    }

    public async Task<List<InvoiceListRow>> GetInvoicesAsync(long? farmId, int year)
    {
        var db = await DbAsync();
        var from = new DateTime(year, 1, 1);
        var to = from.AddYears(1);
        var rows = await db.Table<SalesInvoice>()
            .Where(x => !x.IsDeleted && x.InvoiceDate >= from && x.InvoiceDate < to)
            .OrderByDescending(x => x.InvoiceDate).ToListAsync();
        if (farmId.HasValue && farmId > 0) rows = rows.Where(x => x.FarmId == farmId).ToList();

        var farms = (await GetFarmsAsync()).ToDictionary(x => x.Id, x => x.Name);
        var customers = (await GetCustomerLookupsAsync()).ToDictionary(x => x.Id, x => x.Name);
        return rows.Select(x => new InvoiceListRow
        {
            Invoice = x,
            FarmName = farms.GetValueOrDefault(x.FarmId, "غير معروف"),
            CustomerName = x.CustomerId.HasValue
                ? customers.GetValueOrDefault(x.CustomerId.Value, x.BuyerName ?? "نقدي")
                : x.BuyerName ?? "نقدي"
        }).ToList();
    }

    public async Task CancelInvoiceAsync(long id)
    {
        EnsureAdmin();
        var db = await DbAsync();
        var invoice = await db.FindAsync<SalesInvoice>(id);
        if (invoice is null) return;
        var old = JsonSerializer.Serialize(invoice);
        invoice.Status = InvoiceStatus.Cancelled;
        invoice.ZakatStatus = ZakatPaymentStatus.NotApplicable;
        invoice.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(invoice);
        await AuditAsync("إلغاء فاتورة", nameof(SalesInvoice), id, old, invoice);
    }

    public async Task ConfirmZakatPaidAsync(long id, string? reference)
    {
        if (!_session.CanRecordPayments) throw new InvalidOperationException("تأكيد الزكاة متاح للمدير أو المحاسب.");
        var db = await DbAsync();
        var invoice = await db.FindAsync<SalesInvoice>(id)
            ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
        invoice.ZakatStatus = ZakatPaymentStatus.Paid;
        invoice.ZakatPaidAt = DateTime.Now;
        invoice.ZakatPaymentReference = reference;
        invoice.UpdatedAt = DateTime.Now;
        await db.UpdateAsync(invoice);
        await AuditAsync("تأكيد دفع الزكاة", nameof(SalesInvoice), id, null, invoice);
    }

    public async Task<List<InvoiceListRow>> GetPendingZakatAsync()
    {
        var db = await DbAsync();
        var invoices = await db.Table<SalesInvoice>()
            .Where(x => !x.IsDeleted && x.Status == InvoiceStatus.Posted &&
                        x.ZakatStatus == ZakatPaymentStatus.Pending && x.ZakatAmount > 0)
            .OrderBy(x => x.InvoiceDate).ToListAsync();
        var farms = (await GetFarmsAsync()).ToDictionary(x => x.Id, x => x.Name);
        var customers = (await db.Table<Customer>().Where(x => !x.IsDeleted).ToListAsync())
            .ToDictionary(x => x.Id, x => x.Name);
        return invoices.Select(x => new InvoiceListRow
        {
            Invoice = x,
            FarmName = farms.GetValueOrDefault(x.FarmId, "غير معروف"),
            CustomerName = x.CustomerId.HasValue
                ? customers.GetValueOrDefault(x.CustomerId.Value, x.BuyerName ?? "نقدي")
                : x.BuyerName ?? "نقدي"
        }).ToList();
    }

    public async Task<DashboardSummary> GetDashboardAsync()
    {
        var db = await DbAsync();
        var today = DateTime.Today;
        var from = new DateTime(today.Year, 1, 1);
        var to = from.AddYears(1);
        // Load the small local tables first, then filter in memory. This avoids
        // provider-specific expression translation failures on some Android devices.
        var invoiceRows = await db.Table<SalesInvoice>().ToListAsync();
        var cultivationRows = await db.Table<CultivationExpense>().ToListAsync();

        var invoices = invoiceRows.Where(x => !x.IsDeleted &&
            x.Status == InvoiceStatus.Posted &&
            x.InvoiceDate >= from && x.InvoiceDate < to).ToList();
        var cultivation = cultivationRows.Where(x => !x.IsDeleted &&
            x.ExpenseDate >= from && x.ExpenseDate < to).ToList();

        return new DashboardSummary
        {
            SalesToday = invoices.Where(x => x.InvoiceDate.Date == today).Sum(x => x.GrossAmount),
            SalesYear = invoices.Sum(x => x.GrossAmount),
            NetYear = invoices.Sum(x => x.NetAmount) - cultivation.Sum(x => x.Amount),
            CustomerDebts = invoices.Sum(x => x.AmountDue),
            CultivationDebts = cultivation.Sum(x => Math.Max(0, x.Amount - x.PaidAmount)),
            PendingZakat = invoices.Where(x => x.ZakatStatus == ZakatPaymentStatus.Pending).Sum(x => x.ZakatAmount),
            InvoiceCountYear = invoices.Count,
            OverdueDebtCount = cultivation.Count(x => x.Amount > x.PaidAmount &&
                x.DueDate.HasValue && x.DueDate.Value.Date < today)
        };
    }

    public async Task<AnnualFinanceSummary> GetAnnualFinanceSummaryAsync(long farmId, int year)
    {
        var db = await DbAsync();
        var farm = await db.FindAsync<Farm>(farmId) ?? throw new InvalidOperationException("المزرعة غير موجودة.");
        var from = new DateTime(year, 1, 1);
        var to = from.AddYears(1);
        var invoices = await db.Table<SalesInvoice>()
            .Where(x => !x.IsDeleted && x.Status == InvoiceStatus.Posted && x.FarmId == farmId &&
                        x.InvoiceDate >= from && x.InvoiceDate < to).ToListAsync();
        var cultivation = await db.Table<CultivationExpense>()
            .Where(x => !x.IsDeleted && x.FarmId == farmId &&
                        x.ExpenseDate >= from && x.ExpenseDate < to).ToListAsync();

        var gross = invoices.Sum(x => x.GrossAmount);
        var collected = invoices.Sum(x => x.AmountPaid);
        var invoiceExpenses = invoices.Sum(x => x.TotalExpenses);
        var zakat = invoices.Sum(x => x.ZakatAmount);
        var cultivationTotal = cultivation.Sum(x => x.Amount);
        var cultivationDebt = cultivation.Sum(x => Math.Max(0, x.Amount - x.PaidAmount));
        var accounting = gross - invoiceExpenses - zakat - cultivationTotal;
        var cashAvailable = collected - invoices.Sum(x => x.ZakatStatus == ZakatPaymentStatus.Paid ? x.ZakatAmount : 0)
            - cultivation.Sum(x => x.PaidAmount) - invoiceExpenses;
        var safe = Math.Max(0, Math.Min(accounting, cashAvailable - cultivationDebt));

        return new AnnualFinanceSummary
        {
            FarmName = farm.Name, Year = year, GrossSales = gross, CollectedSales = collected,
            InvoiceExpenses = invoiceExpenses, Zakat = zakat, CultivationExpenses = cultivationTotal,
            CultivationDebtOutstanding = cultivationDebt, AccountingProfit = accounting,
            SafeDistributableProfit = safe
        };
    }

    public async Task<List<AppUser>> GetUsersAsync()
    {
        EnsureAdmin();
        var db = await DbAsync();
        return await db.Table<AppUser>().Where(x => !x.IsDeleted).OrderBy(x => x.FullName).ToListAsync();
    }

    public async Task SaveUserAsync(UserEditModel model)
    {
        EnsureAdmin();
        if (string.IsNullOrWhiteSpace(model.FullName) || string.IsNullOrWhiteSpace(model.Email))
            throw new InvalidOperationException("الاسم والبريد مطلوبان.");
        var db = await DbAsync();
        var email = model.Email.Trim().ToLowerInvariant();

        if (model.Id == 0)
        {
            if (string.IsNullOrWhiteSpace(model.Password) || model.Password.Length < 8)
                throw new InvalidOperationException("كلمة المرور يجب ألا تقل عن 8 أحرف.");
            if (await db.Table<AppUser>().Where(x => x.Email == email && !x.IsDeleted).CountAsync() > 0)
                throw new InvalidOperationException("البريد مستخدم مسبقًا.");
            var (hash, salt) = PasswordHasher.HashPassword(model.Password);
            var user = new AppUser
            {
                FullName = model.FullName.Trim(), Email = email,
                PasswordHash = hash, PasswordSalt = salt,
                Role = model.Role, IsActive = model.IsActive
            };
            await db.InsertAsync(user);
            await AuditAsync("إنشاء مستخدم", nameof(AppUser), user.Id, null, user);
        }
        else
        {
            var user = await db.FindAsync<AppUser>(model.Id) ?? throw new InvalidOperationException("المستخدم غير موجود.");
            if (await db.Table<AppUser>().Where(x => x.Id != user.Id && x.Email == email && !x.IsDeleted).CountAsync() > 0)
                throw new InvalidOperationException("البريد مستخدم مسبقًا.");
            if (_session.CurrentUser?.Id == user.Id && !model.IsActive)
                throw new InvalidOperationException("لا يمكنك إيقاف حسابك الحالي.");
            var removesAdministrator = user.Role == UserRole.Administrator &&
                (model.Role != UserRole.Administrator || !model.IsActive);
            if (removesAdministrator)
            {
                var otherAdmins = await db.Table<AppUser>()
                    .Where(x => x.Id != user.Id && !x.IsDeleted && x.IsActive && x.Role == UserRole.Administrator)
                    .CountAsync();
                if (otherAdmins == 0) throw new InvalidOperationException("لا يمكن إيقاف أو تغيير دور آخر مدير نشط.");
            }
            var oldUser = JsonSerializer.Serialize(user);
            user.FullName = model.FullName.Trim();
            user.Email = email;
            user.Role = model.Role;
            user.IsActive = model.IsActive;
            user.UpdatedAt = DateTime.Now;
            if (!string.IsNullOrWhiteSpace(model.Password))
            {
                var (hash, salt) = PasswordHasher.HashPassword(model.Password);
                user.PasswordHash = hash; user.PasswordSalt = salt;
            }
            await db.UpdateAsync(user);
            await AuditAsync("تعديل مستخدم", nameof(AppUser), user.Id, oldUser, user);
        }
    }

    public async Task<List<AuditLog>> GetAuditLogsAsync(int take = 300)
    {
        EnsureAdmin();
        var db = await DbAsync();
        return await db.Table<AuditLog>().OrderByDescending(x => x.ActionDate).Take(take).ToListAsync();
    }

    public async Task<(SalesInvoice Invoice, Farm Farm, Customer? Customer, List<SalesInvoiceItem> Items,
        List<InvoiceExpense> Expenses, Dictionary<long,string> QatTypes, Dictionary<long,string> ExpenseTypes)>
        GetInvoiceDetailsAsync(long id)
    {
        var db = await DbAsync();
        var invoice = await db.FindAsync<SalesInvoice>(id) ?? throw new InvalidOperationException("الفاتورة غير موجودة.");
        var farm = await db.FindAsync<Farm>(invoice.FarmId) ?? new Farm { Name = "غير معروف" };
        var customer = invoice.CustomerId.HasValue ? await db.FindAsync<Customer>(invoice.CustomerId.Value) : null;
        var items = await db.Table<SalesInvoiceItem>().Where(x => x.InvoiceId == id && !x.IsDeleted).ToListAsync();
        var expenses = await db.Table<InvoiceExpense>().Where(x => x.InvoiceId == id && !x.IsDeleted).ToListAsync();
        var qatTypes = (await GetQatTypesAsync()).ToDictionary(x => x.Id, x => x.Name);
        var expenseTypes = (await GetDailyExpenseTypesAsync()).ToDictionary(x => x.Id, x => x.Name);
        return (invoice, farm, customer, items, expenses, qatTypes, expenseTypes);
    }
}
