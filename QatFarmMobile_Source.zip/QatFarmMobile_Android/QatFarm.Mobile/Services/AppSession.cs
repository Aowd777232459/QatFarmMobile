using QatFarm.Mobile.Data;
using QatFarm.Mobile.Models;

namespace QatFarm.Mobile.Services;

public sealed class AppSession
{
    private readonly MobileDb _db;
    public AppSession(MobileDb db) => _db = db;

    public AppUser? CurrentUser { get; private set; }
    public bool IsAuthenticated => CurrentUser is not null;
    public bool IsAdmin => CurrentUser?.Role == UserRole.Administrator;
    public bool CanRecordPayments => CurrentUser?.Role is UserRole.Administrator or UserRole.Accountant;
    public event Action? Changed;

    public async Task<(bool Success, string Message)> LoginAsync(string email, string password)
    {
        var db = await _db.GetAsync();
        var normalized = email.Trim().ToLowerInvariant();
        var user = await db.Table<AppUser>()
            .Where(x => x.Email == normalized && !x.IsDeleted)
            .FirstOrDefaultAsync();
        if (user is null || !user.IsActive) return (false, "الحساب غير موجود أو موقوف.");
        if (!PasswordHasher.Verify(password, user.PasswordHash, user.PasswordSalt))
            return (false, "كلمة المرور غير صحيحة.");
        user.LastLoginAt = DateTime.Now;
        await db.UpdateAsync(user);
        CurrentUser = user;
        Changed?.Invoke();
        return (true, string.Empty);
    }

    public void Logout() { CurrentUser = null; Changed?.Invoke(); }
}
