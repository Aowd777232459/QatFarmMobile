@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"

echo ============================================================
echo QatFarm Mobile - Build signed Android APK
echo ============================================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET 10 SDK is not installed.
  echo Run PREPARE_ANDROID_TOOLS.cmd as administrator.
  if not defined QATFARM_NO_PAUSE pause
  exit /b 1
)

for /f "tokens=1 delims=." %%V in ('dotnet --version') do set "DOTNET_MAJOR=%%V"
if not "%DOTNET_MAJOR%"=="10" (
  echo ERROR: .NET 10 SDK is required. Current version:
  dotnet --version
  if not defined QATFARM_NO_PAUSE pause
  exit /b 1
)

echo [1/6] Checking the .NET MAUI Android workload...
dotnet workload list | findstr /i "maui-android" >nul
if errorlevel 1 (
  echo Installing the MAUI Android workload...
  dotnet workload install maui-android
  if errorlevel 1 (
    echo ERROR: Android workload installation failed.
    echo Run PREPARE_ANDROID_TOOLS.cmd as administrator.
    if not defined QATFARM_NO_PAUSE pause
    exit /b 1
  )
)
dotnet workload restore "QatFarm.Mobile\QatFarm.Mobile.csproj"
if errorlevel 1 goto :failed

echo [2/6] Restoring NuGet packages...
dotnet restore "QatFarm.Mobile\QatFarm.Mobile.csproj" --configfile "%~dp0NuGet.config"
if errorlevel 1 goto :failed

echo [3/6] Compiling the Android project...
dotnet build "QatFarm.Mobile\QatFarm.Mobile.csproj" -f net10.0-android -c Release --no-restore
if errorlevel 1 goto :failed

echo [4/6] Locating Java keytool...
set "KEYTOOL="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\keytool.exe" set "KEYTOOL=%JAVA_HOME%\bin\keytool.exe"
if not defined KEYTOOL for /f "delims=" %%I in ('where keytool.exe 2^>nul') do if not defined KEYTOOL set "KEYTOOL=%%I"
if not defined KEYTOOL for /f "delims=" %%I in ('where /r "%ProgramFiles%\Microsoft" keytool.exe 2^>nul') do if not defined KEYTOOL set "KEYTOOL=%%I"
if not defined KEYTOOL for /f "delims=" %%I in ('where /r "%ProgramFiles(x86)%\Microsoft" keytool.exe 2^>nul') do if not defined KEYTOOL set "KEYTOOL=%%I"
if not defined KEYTOOL (
  echo ERROR: keytool.exe was not found.
  echo Open Visual Studio Installer and add: Mobile development with .NET
  if not defined QATFARM_NO_PAUSE pause
  exit /b 1
)

if not exist "Signing" mkdir "Signing"
if not exist "Signing\QatFarmMobile.keystore" (
  echo Creating the permanent signing key...
  "%KEYTOOL%" -genkeypair -v -keystore "Signing\QatFarmMobile.keystore" -alias qatfarm -keyalg RSA -keysize 2048 -validity 10000 -storepass "QatFarm@2026" -keypass "QatFarm@2026" -dname "CN=QatFarm Mobile, OU=QatFarm, O=QatFarm, L=Sanaa, ST=Yemen, C=YE"
  if errorlevel 1 goto :failed
)

echo [5/6] Publishing the signed universal APK...
dotnet publish "QatFarm.Mobile\QatFarm.Mobile.csproj" ^
  -f net10.0-android ^
  -c Release ^
  --no-restore ^
  -p:AndroidPackageFormats=apk ^
  -p:AndroidCreatePackagePerAbi=false ^
  -p:AndroidKeyStore=true ^
  -p:AndroidSigningKeyStore="%~dp0Signing\QatFarmMobile.keystore" ^
  -p:AndroidSigningKeyAlias=qatfarm ^
  -p:AndroidSigningKeyPass="QatFarm@2026" ^
  -p:AndroidSigningStorePass="QatFarm@2026" ^
  -p:PublishTrimmed=false ^
  -p:RunAOTCompilation=false ^
  -p:DebugSymbols=false ^
  -p:DebugType=None
if errorlevel 1 goto :failed

echo [6/6] Collecting the APK...
if not exist "Release" mkdir "Release"
del /q "Release\QatFarmMobile.apk" 2>nul
for /r "QatFarm.Mobile\bin\Release\net10.0-android" %%F in (*-Signed.apk) do if not exist "Release\QatFarmMobile.apk" copy /y "%%F" "Release\QatFarmMobile.apk" >nul
if not exist "Release\QatFarmMobile.apk" for /r "QatFarm.Mobile\bin\Release\net10.0-android" %%F in (*.apk) do if not exist "Release\QatFarmMobile.apk" copy /y "%%F" "Release\QatFarmMobile.apk" >nul
if not exist "Release\QatFarmMobile.apk" (
  echo ERROR: Build succeeded but the APK was not found.
  goto :failed
)

for %%F in ("Release\QatFarmMobile.apk") do echo APK size: %%~zF bytes
echo ============================================================
echo SUCCESS
echo APK: %~dp0Release\QatFarmMobile.apk
echo Keep the Signing folder safe for future updates.
echo ============================================================
if not defined QATFARM_NO_PAUSE pause
exit /b 0

:failed
echo ERROR: Android APK build failed. Review the message above.
if not defined QATFARM_NO_PAUSE pause
exit /b 1
