using Microsoft.EntityFrameworkCore;
using QatFarm.Web.Data;
using QatFarm.Web.Models;

namespace QatFarm.Web.Services;

public sealed class LookupService(IDbContextFactory<ApplicationDbContext> factory)
{
    public async Task<List<LookupItem>> FarmsAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.Farms.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name)).ToListAsync();
    }

    public async Task<List<LookupItem>> FarmsForReportsAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.Farms
            .IgnoreQueryFilters()
            .AsNoTracking()
            .OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name))
            .ToListAsync();
    }

    public async Task<List<int>> ReportingYearsAsync()
    {
        await using var db = await factory.CreateDbContextAsync();

        var invoiceYears = await db.SalesInvoices
            .AsNoTracking()
            .Select(x => x.InvoiceDate.Year)
            .Distinct()
            .ToListAsync();

        var cultivationYears = await db.CultivationExpenses
            .AsNoTracking()
            .Select(x => x.ExpenseDate.Year)
            .Distinct()
            .ToListAsync();

        return invoiceYears
            .Concat(cultivationYears)
            .Append(DateTime.Today.Year)
            .Where(x => x >= 2000 && x <= DateTime.Today.Year + 1)
            .Distinct()
            .OrderByDescending(x => x)
            .ToList();
    }

    public async Task<List<LookupItem>> CustomersAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.Customers.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name + (x.Phone == null ? "" : " — " + x.Phone))).ToListAsync();
    }

    public async Task<List<LookupItem>> CreditorsAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.Creditors.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name + (x.Phone == null ? "" : " — " + x.Phone)))
            .ToListAsync();
    }

    public async Task<List<LookupItem>> QatTypesAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.QatTypes.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name)).ToListAsync();
    }

    public async Task<List<LookupItem>> CultivationExpenseTypesAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.CultivationExpenseTypes.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name)).ToListAsync();
    }

    public async Task<List<LookupItem>> DailyExpenseTypesAsync()
    {
        await using var db = await factory.CreateDbContextAsync();
        return await db.DailyExpenseTypes.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name)
            .Select(x => new LookupItem(x.Id, x.Name)).ToListAsync();
    }
}
